object oIndex{
	var pIndex=0
}